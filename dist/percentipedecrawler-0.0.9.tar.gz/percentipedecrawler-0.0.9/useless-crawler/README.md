# useless-crawler is now uselesscrawler

This package has been renamed. Use `pip install uselesscrawler` instead.

New package: https://pypi.org/project/uselesscrawler/
